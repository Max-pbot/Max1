--- Retained for compatibility reasons only. Use luarocks.loader instead.
return require("luarocks.loader")
