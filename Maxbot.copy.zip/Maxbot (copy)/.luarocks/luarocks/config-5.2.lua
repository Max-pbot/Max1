rocks_trees = {
   { name = [[system]], root = [[/home/pouriya/Maxbot/.luarocks]] }
}
