do

function run(msg, matches)
return [[ 
Tele Sick Anti Spam Bot Ver . 8.5
Ali Destroyer [Founder][Coder][Sudo]
Matin Shadow [Tester]
Manan.k [Tester]
Mohammad TicTic [Helper]
Pooria.w [Supporter]
Jan123 [Supporter]
MehranUX [Sucker :D]
have any question ? @shopbuy
]]
end

return {
description = "Shows bot about text", 
usage = " TeleSick : Show Creators",
patterns = {
"^[!/][tT]elesick$"
"^[tT]eleSick$"
}, 
run = run 
}

end
